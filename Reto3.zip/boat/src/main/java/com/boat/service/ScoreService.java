package com.boat.service;
import com.boat.model.Score;
import com.boat.repository.ScoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Service
public class ScoreService {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private ScoreRepository scoreRepository;
    /**
     * @return Servicio que lista los elementos de la base de datos
     */
    public List<Score> getAll() {
        return scoreRepository.getAll();
    }
    /**
     * @param scoreId
     * @return Servicio que lista un elemento especeifico de la base de datos
     */
    public Optional<Score> getScore(int scoreId) {
        return scoreRepository.getScore(scoreId);
    }
    /**
     * @param score
     * @return Servicio que crea un nuevo registro en la base de datos
     */
    public Score save(Score score) {
        if (score.getStars() >= 0 && score.getStars() <= 5) {
            if (score.getIdScore() == null) {
                return scoreRepository.save(score);
            } else {
                Optional<Score> e = scoreRepository.getScore(score.getIdScore());
                if (e.isEmpty()) {
                    return scoreRepository.save(score);
                }
            }
        }
        return score;
    }
}