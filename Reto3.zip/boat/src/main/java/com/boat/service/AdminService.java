package com.boat.service;
import com.boat.model.Admin;
import com.boat.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Service
public class AdminService {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private AdminRepository adminRepository;
    /**
     * @return Servicio que lista los elementos de la base de datos
     */
    public List<Admin> getAll() {
        return adminRepository.getAll();
    }
    /**
     * @param adminId
     * @return Servicio que lista un elemento especeifico de la base de datos
     */
    public Optional<Admin> getAdmin(int adminId) {
        return adminRepository.getAdmin(adminId);
    }
    /**
     * @param admin
     * @return Servicio que crea un nuevo registro en la base de datos
     */
    public Admin save(Admin admin) {
        if (admin.getIdAdmin() == null) {
            return adminRepository.save(admin);
        } else {
            Optional<Admin> admin1 = adminRepository.getAdmin(admin.getIdAdmin());
            if (admin1.isEmpty()) {
                return adminRepository.save(admin);
            } else {
                return admin;
            }
        }
    }
}