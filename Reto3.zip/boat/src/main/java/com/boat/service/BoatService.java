package com.boat.service;
import com.boat.model.Boat;
import com.boat.repository.BoatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Service
public class BoatService {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private BoatRepository boatRepository;
    /**
     * @return Servicio que lista los elementos de la base de datos
     */
    public List<Boat> getAll() {
        return boatRepository.getAll();
    }
    /**
     * @param id
     * @return Servicio que lista un elemento especeifico de la base de datos
     */
    public Optional<Boat> getBoat(int id) {
        return boatRepository.getBoat(id);
    }
    /**
     * @param boat
     * @return Servicio que crea un nuevo registro en la base de datos
     */
    public Boat save(Boat boat) {
        if (boat.getId() == null) {
            return boatRepository.save(boat);
        } else {
            Optional<Boat> e = boatRepository.getBoat(boat.getId());
            if (e.isEmpty()) {
                return boatRepository.save(boat);
            } else {
                return boat;
            }
        }
    }
}