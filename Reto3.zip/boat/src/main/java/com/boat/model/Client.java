package com.boat.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.persistence.*;
import java.io.Serializable;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Entity
@Table(name = "client")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Client implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    /**
     * Identificador del cliente
     */
    private Integer idClient;
    /**
     * Correo del cliente
     */
    private String email;
    /**
     * Contraseña del cliente
     */
    private String password;
    /**
     * Nombre del cliente
     */
    private String name;
    /**
     * Edad del cliente
     */
    private Integer age;
    /**
     * Modelo relacional de muchos a uno entre Cliente y Mensaje
     */
    @OneToMany(cascade = {CascadeType.PERSIST},mappedBy="client")
    @JsonIgnoreProperties("client")
    public List<Message>messages;
    /**
     * Modelo relacional de uno a muchos entre Cliente y Reserva
     */
    @OneToMany(cascade = {CascadeType.PERSIST},mappedBy="client")
    @JsonIgnoreProperties("client")
    public List<Reservation>reservations;
}