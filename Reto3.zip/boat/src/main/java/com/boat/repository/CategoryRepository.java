package com.boat.repository;
import com.boat.model.Category;
import com.boat.repository.crud.CategoryCrudRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Repository
public class CategoryRepository {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private CategoryCrudRepository categoryCrudRepository;
    /**
     * @return Contiene la interfaz que extiende de JPA para que el metodo que lista todos los elementos se conecte a la base de datos
     */
    public List<Category> getAll(){
        return (List<Category>) categoryCrudRepository.findAll();
    }
    /**
     * @param id Contiene la interfaz que extiende de JPA para que el metodo que lista un solo elemento se conecte a la base de datos
     * @return 
     */
    public Optional<Category> getCategory(int id){
        return categoryCrudRepository.findById(id);
    }
    /**
     * @param category Contiene la interfaz que extiende de JPA para que el metodo que crea un nuevo registro se conecte a la base de datos
     * @return 
     */
    public Category save(Category category){
        return categoryCrudRepository.save(category);
    }
}