package com.boat.repository;
import com.boat.model.Message;
import com.boat.repository.crud.MessageCrudRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Repository
public class MessageRepository {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private MessageCrudRepository messageCrudRepository;
    /**
     * @return Contiene la interfaz que extiende de JPA para que el metodo que lista todos los elementos se conecte a la base de datos
     */
    public List<Message> getAll(){
        return (List<Message>) messageCrudRepository.findAll();
    }
    /**
     * @param id Contiene la interfaz que extiende de JPA para que el metodo que lista un solo elemento se conecte a la base de datos
     * @return 
     */
    public Optional<Message> getMessage(int id){
        return messageCrudRepository.findById(id);
    }
    /**
     * @param message Contiene la interfaz que extiende de JPA para que el metodo que crea un nuevo registro se conecte a la base de datos
     * @return 
     */
    public Message save(Message message){
        return messageCrudRepository.save(message);
    }
}