package com.boat.service;
import com.boat.model.Reservation;
import com.boat.repository.ReservationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Service
public class ReservationService {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private ReservationRepository reservationRepository;
    /**
     * @return Servicio que lista los elementos de la base de datos
     */
    public List<Reservation> getAll() {
        return reservationRepository.getAll();
    }
    /**
     * @param reservationId
     * @return Servicio que lista un elemento especeifico de la base de datos
     */
    public Optional<Reservation> getReservation(int reservationId) {
        return reservationRepository.getReservation(reservationId);
    }
    /**
     * @param reservation
     * @return Servicio que crea un nuevo registro en la base de datos
     */
    public Reservation save(Reservation reservation) {
        if (reservation.getIdReservation() == null) {
            return reservationRepository.save(reservation);
        } else {
            Optional<Reservation> e = reservationRepository.getReservation(reservation.getIdReservation());
            if (e.isEmpty()) {
                return reservationRepository.save(reservation);
            } else {
                return reservation;
            }
        }
    }
}